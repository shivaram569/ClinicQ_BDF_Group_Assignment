# ClinicQ Health Centre - Consultation Room Booking System
### Backend Development Fundamentals (BDF) · Group Assignment
**Class & Section:** `313 AI DE 2B` | **Study Level:** `UG` | **Year & Term:** `2 & 2`  
**Subject:** `Backend Development Fundamentals` | **Faculty:** `Mr Yugandhar Gurjalwar`  
**Group ID:** `YG-AIDE2B-G08` (Group 8 of 15) | **Theme:** `Theme 23 of 30 · Consultation rooms` | **Card:** `Card 83 of 375`  
**Assessment:** `GROUP ASSIGNMENT` (100 Marks: 70 Group + 30 Individual Demo & Viva)

---

## 1. Problem Statement & Client Brief
> *"Consultation rooms are assigned by the receptionist. Two doctors were given the same room at the same hour. Please build us a system that fixes this."*

ClinicQ Health Centre required a robust backend reservation system to manage doctors, consultation rooms, and schedule appointments without double-booking rooms. Additionally, the clinic required real-time room availability intelligence via the **"Free on this date"** assignment twist.

---

## 2. LG Group Members & Contribution Allocation

| S.No. | Student Name | Registration No. | Contribution Folder | Assigned Responsibility |
|:---:|:---|:---:|:---|:---|
| **1** | **m.chatish kuldeep** | `252U1R5102` | `CONTRIBUTION_1_SERVER_AND_ROUTES` | **Server & Routes:** Express setup, routing architecture, status codes, logger & error handlers. |
| **2** | **o.sai kiran** | `252U1R5116` | `CONTRIBUTION_2_DATABASE` | **Database Architecture:** SQLite connection, `PRAGMA foreign_keys = ON`, schema, seed data & queries. |
| **3** | **M.SHIVARAM** | `252U1R5104` | `CONTRIBUTION_3_REST_ENDPOINTS` | **REST Endpoints:** Complete CRUD operations for doctors, rooms, bookings; SQL JOIN details endpoint. |
| **4** | **k.harshith** | `252U1R5083` | `CONTRIBUTION_4_VALIDATION_AND_SEARCH` | **Validation & Search:** Input validation middleware, error messages, query search (`GET /rooms?floor=2`). |
| **5** | **n.bhupal reddy** | `252U1R5114` | `CONTRIBUTION_5_TWIST_RULE` | **Assignment Twist:** `GET /rooms/available?date=YYYY-MM-DD` via `NOT EXISTS`, overlap conflict prevention. |
| **6** | **k.lava kumar** | `252U1R5086` | `CONTRIBUTION_6_POSTMAN_AND_README` | **Postman & Documentation:** Postman v2.1 collection with assertions, test runner, full documentation. |

---

## 3. Project Directory Structure

```
ClinicQ_BDF_Group_Assignment/
│
├── main-project/                        # Fully integrated working application
│   ├── config/db.js                     # SQLite connection & promise wrappers
│   ├── controllers/                     # Route controllers (doctors, rooms, bookings)
│   ├── database/                        # Schema, seed SQL & init script
│   ├── middleware/                      # Request logger, input validator, error handlers
│   ├── routes/                          # Express routers (doctors, rooms, bookings)
│   ├── postman/                         # Postman collection & environment JSON
│   ├── app.js                           # Express application setup
│   ├── server.js                        # Server entry point
│   ├── test-runner.js                   # Automated 25-step test suite
│   └── package.json                     # Main dependencies
│
├── CONTRIBUTION_1_SERVER_AND_ROUTES/    # Pack for m.chatish kuldeep (252U1R5102)
│   ├── source-code/                     # Member 1 code files
│   ├── screenshots/                     # Real terminal & editor screenshots
│   ├── assessment-document/             # DOCX and PDF academic reports
│   └── README.md                        # Explanations & viva prep
│
├── CONTRIBUTION_2_DATABASE/             # Pack for o.sai kiran (252U1R5116)
│   ├── source-code/                     # SQLite config, schema, seed, init
│   ├── screenshots/                     # Schema, table rows, relations
│   ├── assessment-document/             # DOCX and PDF academic reports
│   └── README.md                        # Explanations & viva prep
│
├── CONTRIBUTION_3_REST_ENDPOINTS/       # Pack for M.SHIVARAM (252U1R5104)
│   ├── source-code/                     # Doctors, Rooms, Bookings controllers
│   ├── postman/                         # Demo Postman Collection & Environment JSON
│   ├── screenshots/                     # CRUD execution & SQL JOIN output
│   ├── assessment-document/             # DOCX and PDF academic reports
│   └── README.md                        # Comprehensive 3-minute Live Demo script & Viva Q&A
│
├── CONTRIBUTION_4_VALIDATION_AND_SEARCH/# Pack for k.harshith (252U1R5083)
├── CONTRIBUTION_5_TWIST_RULE/           # Pack for n.bhupal reddy (252U1R5114)
├── CONTRIBUTION_6_POSTMAN_AND_README/   # Pack for k.lava kumar (252U1R5086)
│
├── shared/                              # Shared resources across team
│   ├── database/                        # Central database files
│   ├── postman-collection/              # Central Postman exports
│   ├── screenshots/                     # High-res screenshots archive
│   └── group-information/               # Group manifest & original brief image
│
├── Complete_Assignment.zip              # Complete group assignment package
├── Contribution_1.zip                   # m.chatish kuldeep submission pack
├── Contribution_2.zip                   # o.sai kiran submission pack
├── Contribution_3.zip                   # M.SHIVARAM submission pack
├── Contribution_4.zip                   # k.harshith submission pack
├── Contribution_5.zip                   # n.bhupal reddy submission pack
├── Contribution_6.zip                   # k.lava kumar submission pack
├── package.json                         # Root NPM configuration
└── README.md                            # Comprehensive Master README
```

---

## 4. Quickstart: How to Run the Project

### 4.1 Prerequisites
- **Node.js**: v18.0.0 or higher (Installed: Node.js v26.13.0)
- **npm**: v9.0.0 or higher
- **Postman**: Desktop application for executing the API collection

### 4.2 Installation & Database Initialization
```bash
cd "C:\Users\mokeda shivaram\.gemini\antigravity\scratch\ClinicQ_BDF_Group_Assignment\main-project"
npm install
npm run init-db
```
*Output:*
```
Schema applied successfully.
Seed data inserted successfully.
Database Summary:
  - Table: doctors    | Records: 5
  - Table: rooms      | Records: 6
  - Table: bookings   | Records: 3
```

### 4.3 Start Server
```bash
npm start
```
The server will start listening at `http://localhost:3000`.

### 4.4 Automated 25-Step Test Suite
```bash
npm test
```
*Result: 25/25 Tests Passing (100% Success Rate).*

---

## 5. Verification of the 3 Compulsory Twist Test Cases

| Test Case | Scenario / Request | Expected Result | Verified Result | Status |
|:---|:---|:---|:---|:---:|
| **Test 1** | `POST /bookings`<br>Start: `2026-11-15`<br>End: `2026-11-14` | `HTTP 400 Bad Request`<br>`"End date cannot be earlier than start date."` | Status: `400`<br>Error: `"End date cannot be earlier than start date."` | **PASS** |
| **Test 2** | `GET /rooms/available?date=2026-11-11`<br>(Room 3 has active booking 10-12 Nov) | `HTTP 200 OK`<br>Room 3 must **NOT** appear in the response | Status: `200`<br>Room 3 present: `false` | **PASS** |
| **Test 3** | `GET /rooms/available?date=2026-11-13`<br>(Booking ended on 12 Nov) | `HTTP 200 OK`<br>Room 3 **MUST** appear in the response | Status: `200`<br>Room 3 present: `true` | **PASS** |

---

## 6. Live Demo Instructions for Monday 16 Nov (3-Minute Live Demo)

### Structure of the 3-Minute Demo:
1. **Minute 1: System Overview & Server Startup (m.chatish kuldeep & o.sai kiran)**
   - Start server: `npm start` on `http://localhost:3000`.
   - Show SQLite database tables (`doctors`, `rooms`, `bookings`) with foreign keys enabled.
2. **Minute 2: REST Endpoints & SQL JOIN Demo (M.SHIVARAM - Contribution 3)**
   - Open Postman, run Doctor CRUD, Room CRUD, and Booking CRUD.
   - Execute `GET http://localhost:3000/bookings/details` showing the relational SQL `JOIN` returning Doctor Name and Room Number.
3. **Minute 3: Validation, Search & The Assignment Twist (k.harshith, n.bhupal reddy & k.lava kumar)**
   - Show `GET /rooms?floor=2` returning only floor 2 rooms.
   - Run the 3 Twist tests: Test 1 (400 on invalid date), Test 2 (Room 3 missing on Nov 11), Test 3 (Room 3 listed on Nov 13).
   - Show Postman test collection runner passing 100%.
